trait FSets {

  def profileID:Int = 326860

  /* write a function which takes an integer and returns the set containing that integer:
   */
  def singleton(x: Int): Int => Boolean = (y: Int) => y == x

  /* write a function which takes a set and an integer, and returns true if the integer is a member of the set.
     The function should be curried.
   */
  def member(set: Int => Boolean)(e: Int): Boolean = set(e)

  /* write a function which takes two integer bounds, and returns the set containing all integers
     between the bounds. Hint: you can use a tail-recursive function together with singleton, but there is
     also a simpler way.
   */
  def fromBounds(start: Int, stop: Int): Int => Boolean = (y: Int) => start <= y && stop >= y

  /* write intersection and reunion of two sets */

  def intersection(set1: Int => Boolean, set2: Int => Boolean): Int => Boolean = (y: Int) => member(set1)(y) && member(set2)(y)

  def union(set1: Int => Boolean, set2: Int => Boolean): Int => Boolean = (y: Int) => member(set1)(y) || member(set2)(y)

  /* write a function which takes bounds, as well as a set, and computes the sum of all
     elements from the set. Use inner (tail-recursive) functions
   */

  def sumSet(start: Int, stop: Int, set: Int => Boolean): Int = {
    def auxSum(crt: Int, acc: Int): Int = {
      if(crt > stop) acc
      else if (member(set)(crt)) auxSum(crt + 1, acc + crt)
      else auxSum(crt + 1, acc)
    }

    auxSum(start, 0)
  }

  /* generalise the previous function such that we can fold the set using any binary commutative
     operation over integers;
   */
  def foldSet(
               start: Int,            // bounds (inclusive)
               stop: Int,
               op: (Int, Int) => Int, // folding operation
               initial: Int,          // initial value
               set: Int => Boolean    // the set to be folded
             ): Int = {

    def tail_recursive(crt: Int, acc: Int): Int = {
      if(crt > stop) acc
      else if (member(set)(crt)) tail_recursive(crt + 1, op(crt, acc))
      else tail_recursive(crt + 1, acc)
    }

    tail_recursive(start, initial)
  }

  /* implement a function forall which checks if all elements in a given range of a set satisfy a condition */

  def forall(
              start: Int, // start value (inclusive)
              stop: Int, // stop value (inclusive)
              condition: Int => Boolean, // condition to be checked
              set: Int => Boolean // set to be checked
            ): Boolean = {

    def tail_recursive(crt: Int): Boolean = {
      if (crt > stop) true
      else if (member(set)(crt) && !condition(crt)) false
      else tail_recursive(crt + 1)
    }

    tail_recursive(start)
  }


  /* implement a function exists, using forall */
  def exists(
              start: Int, // start value (inclusive)
              stop: Int, // stop value (inclusive)
              condition: Int => Boolean, // condition to be checked
              set: Int => Boolean // set
            ): Boolean = {

    def tail_recursive(crt: Int): Boolean = {
      if (crt > stop) false
      else if (member(set)(crt) && condition(crt)) true
      else tail_recursive(crt + 1)
    }

    tail_recursive(start)
  }
}


object FSets extends FSets
